# 경로 설정
$installDir = "$HOME\Scripts"
$ps1Path = Join-Path $installDir "mygrep.ps1"
$cmdPath = Join-Path $installDir "mygrep.cmd"

# 디렉토리 생성
if (-not (Test-Path $installDir)) {
    New-Item -ItemType Directory -Path $installDir -Force | Out-Null
    Write-Host "📁 Scripts 디렉토리 생성됨: $installDir"
}

# PowerShell 스크립트 저장
$scriptContent = @'
param (
    [Parameter(Mandatory=$true, Position=0)]
    [string]$Pattern,

    [Parameter(Position=1)]
    [string[]]$Files = @(),

    [switch]$IgnoreCase,
    [switch]$LineNumber,
    [switch]$Recursive,
    [switch]$SimpleMatch
)

function Highlight-Match {
    param (
        [string]$line,
        [string]$pattern,
        [bool]$caseInsensitive,
        [bool]$simpleMatch
    )

    $regexOptions = if ($caseInsensitive) { 'IgnoreCase' } else { 'None' }
    if ($simpleMatch) {
        $pattern = [Regex]::Escape($pattern)
    }

    [regex]$regex = New-Object System.Text.RegularExpressions.Regex($pattern, $regexOptions)
    $matches = $regex.Matches($line)

    if ($matches.Count -eq 0) {
        Write-Host $line
        return
    }

    $lastIndex = 0
    foreach ($match in $matches) {
        $prefix = $line.Substring($lastIndex, $match.Index - $lastIndex)
        Write-Host -NoNewline $prefix
        Write-Host -NoNewline $match.Value -ForegroundColor Yellow
        $lastIndex = $match.Index + $match.Length
    }
    Write-Host $line.Substring($lastIndex)
}

$selectStringOptions = @{}
$selectStringOptions["CaseSensitive"] = -not $IgnoreCase
if ($SimpleMatch) {
    $selectStringOptions["SimpleMatch"] = $true
}

if ($Recursive -and $Files.Count -gt 0) {
    $Files = Get-ChildItem -Recurse -File -Path $Files | Select-Object -ExpandProperty FullName
}

if ($Files.Count -eq 0) {
    $input | Select-String -Pattern $Pattern @selectStringOptions | ForEach-Object {
        if ($LineNumber) {
            Write-Host -NoNewline "$($_.LineNumber): "
        }
        Highlight-Match -line $_.Line -pattern $Pattern -caseInsensitive $IgnoreCase -simpleMatch $SimpleMatch
    }
} else {
    Select-String -Pattern $Pattern -Path $Files @selectStringOptions | ForEach-Object {
        $prefix = ""
        if ($_.Filename) { $prefix += "$($_.Filename):" }
        if ($LineNumber) { $prefix += "$($_.LineNumber):" }
        if ($prefix) { Write-Host -NoNewline $prefix }
        Highlight-Match -line $_.Line -pattern $Pattern -caseInsensitive $IgnoreCase -simpleMatch $SimpleMatch
    }
}
'@

Set-Content -Path $ps1Path -Value $scriptContent -Encoding UTF8
Write-Host "✅ PowerShell 스크립트 저장됨: $ps1Path"

# CMD 포워더 생성
$cmdContent = '@echo off
powershell -ExecutionPolicy Bypass -File "%~dp0my-grep.ps1" %*'

Set-Content -Path $cmdPath -Value $cmdContent -Encoding ASCII
Write-Host "✅ CMD 래퍼 생성됨: $cmdPath"

# PATH 등록
$currentPath = [Environment]::GetEnvironmentVariable("PATH", "User")
if ($currentPath -notlike "*$installDir*") {
    [Environment]::SetEnvironmentVariable("PATH", "$currentPath;$installDir", "User")
    Write-Host "🔧 사용자 PATH에 추가됨: $installDir"
} else {
    Write-Host "ℹ️ 이미 PATH에 포함되어 있음."
}

# 실행 정책 설정
$currentPolicy = Get-ExecutionPolicy -Scope CurrentUser
if ($currentPolicy -ne 'RemoteSigned') {
    Set-ExecutionPolicy RemoteSigned -Scope CurrentUser -Force
    Write-Host "🔓 실행 정책 설정 완료: RemoteSigned"
} else {
    Write-Host "ℹ️ 실행 정책 이미 설정됨: $currentPolicy"
}

Write-Host "`n🎉 설치 완료! 이제 'my-grep' 명령어를 어디서든 사용할 수 있습니다."
