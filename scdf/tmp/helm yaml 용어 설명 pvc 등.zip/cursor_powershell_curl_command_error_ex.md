# PowerShell Curl Command Error Explanation
_Exported on 5/23/2025 at 12:49:04 GMT+9 from Cursor (0.50.5)_

---

**User**

파워셀에서 : curl -X POST http://localhost:8080/api/batch/start  실행시 아래와 같이 오류 발생.
Invoke-WebRequest : 매개 변수 이름 'X'과(와) 일치하는 매개 변수를 찾을 수 없습니다.
위치 줄:1 문자:6
+ curl -X POST http://localhost:8080/api/batch/start
+      ~~
    + CategoryInfo          : InvalidArgument: (:) [Invoke-WebRequest], ParameterBindingException
    + FullyQualifiedErrorId : NamedParameterNotFound,Microsoft.PowerShell.Commands.InvokeWebRequestC
   ommand     오류를 확인해서 오류원인 및 상셍 설명 부탁해요

---

**Cursor**

PowerShell에서 발생한 오류에 대해 설명해 드리겠습니다.

이 오류는 PowerShell에서 `curl` 명령어가 실제로 `Invoke-WebRequest` cmdlet의 별칭으로 작동하기 때문에 발생했습니다. PowerShell의 `curl`은 리눅스나 윈도우의 curl.exe와는 다르게 동작합니다.

오류의 주요 원인:
1. PowerShell에서 `-X` 파라미터는 `Invoke-WebRequest` cmdlet에서 인식되지 않는 파라미터입니다.
2. PowerShell의 `curl` 별칭은 리눅스/Unix 스타일의 curl 명령어 구문과 호환되지 않습니다.

해결 방법으로 다음 옵션들을 사용할 수 있습니다:

1. PowerShell에서 올바른 구문 사용:
```powershell
Invoke-WebRequest -Method POST -Uri http://localhost:8080/api/batch/start
```

2. 또는 더 간단하게:
```powershell
Invoke-RestMethod -Method POST http://localhost:8080/api/batch/start
```

3. 실제 curl.exe를 사용하고 싶다면:
```powershell
curl.exe -X POST http://localhost:8080/api/batch/start
```

4. PowerShell 7 이상을 사용중이라면:
```powershell
curl -Method POST http://localhost:8080/api/batch/start
```

추천하는 방법은 `Invoke-RestMethod`를 사용하는 것입니다. 이 명령어는 PowerShell에 최적화되어 있으며, JSON 응답을 자동으로 파싱하는 등의 추가 기능도 제공합니다.

이 API 엔드포인트는 Spring Batch 작업을 시작하는 컨트롤러를 호출하는 것이므로, 성공적으로 요청이 전송되면 "Job started successfully" 응답을 받게 될 것입니다.

```powershell
Invoke-WebRequest -Method POST -Uri http://localhost:8080/api/batch/start
```

```powershell
Invoke-RestMethod -Method POST http://localhost:8080/api/batch/start
```

```powershell
curl.exe -X POST http://localhost:8080/api/batch/start
```

```powershell
curl -Method POST http://localhost:8080/api/batch/start
```

