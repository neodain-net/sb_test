<#
[배경]
윈도우즈 환경의 PowerShell을 이용해서 리눅스 .bashrc나 .zshrc처럼 환경설정을 해볼 수 있는 방법을 찾아보고,
PowerShell의 dot-sourcing 문법을 사용하는 케이스에 대해 알아보자.

[목적]
특정 작업 디렉토리(work) 이동을 쉽게 하기위해 cdw를 입력하면 "C:\Users\SKTelecom\work\" 로 이동하도록
환경설정을 해보자

$PROFILE
- $PROFILE 은 PowerShell이 시작될 때 자동으로 로드하는 사용자별 시작 스크립트 경로를 담고 있는 내장 변수.
- 기본적인 구조 : C:\Users\<사용자명>\Documents\PowerShell\Microsoft.PowerShell_profile.ps1
- 직접 변경할 수 없는 읽기 전용 내장 변수입니다. 따라서, 다른값으로 할당 할 수 없다.
- 하지만 다른 스크립트를 수동으로 불러 올 수 있다(dot sourcing)
- 이것은 bash의 source ~/.bashrc_custom과 비슷한 방식으로 이해하면 된다.

PowerShell은 다양한 스코프에 따라 여러 프로파일을 지원한다.
변수	                                    설명
$PROFILE	                                    현재 사용자 + 현재 호스트
$PROFILE.AllUsersCurrentHost	모든 사용자 + 현재 호스트
$PROFILE.CurrentUserAllHosts	현재 사용자 + 모든 호스트
$PROFILE.AllUsersAllHosts	            모든 사용자 + 모든 호스트


PS C:\Users\SKTelecom\work\sandbox\tools\powershell> $PROFILE.AllUsersCurrentHost
C:\Windows\System32\WindowsPowerShell\v1.0\Microsoft.PowerShell_profile.ps1
스코프에 따라 파일 위치가 다름을 알 수 있다.
#>

# [구현]
# 
# 명령 cmd에서 cdw를 치면 'C:\Users\SKTelecom\work\' 로 이동하는 함수를 작성한다. 

function cdw {
    Set-Location 'C:\Users\SKTelecom\work\'
}

function cdp {
    Set-Location 'C:\Users\SKTelecom\work\skt_oss\projects\'
}

function cds {
    Set-Location 'C:\Users\SKTelecom\work\sandbox\'
}

function cdjs {
    Set-Location 'C:\Users\SKTelecom\work\sandbox\java\spring_boot\'
}

<#
동일하게 MINGW를 사용한다면, Git이 설치된 디렉토리의 etc/profile 파일을 아래와 같이 alias를 추가할 수 있다.
(PowerShell 관리자 모드로 > notepad profile 수정 후 저장, 새로 GitBash 시작하면 적용됨.)
(위치 - C:\Program Files\Git\etc\profile)

alias ls='ls --color=auto --show-control-chars'
alias ll='ls -al --color=auto --show-control-chars'

alias cdp='cd /c/Users/SKTelecom/work/skt_oss/projects'
alias cdw='cd /c/Users/SKTelecom/work'
alias cds='cd /c/Users/SKTelecom/work/sandbox'
alias cdjs='cd /c/Users/SKTelecom/work/sandbox/java/spring_boot'

#>