<#
PowerShell 환경 설정 파일 
PowerShell 프로필에 함수 추가하여 리눅스의 쉘 환경설정 처럼 해보기

funtion cdw {
    Set-Location -Path 'C:\Users\work\project\'
}

#>

# dot sourcing
. "C:\Users\SKTelecom\work\sandbox\tools\powershell\user_profile.ps1"


<#
PowerShell 은 기본적으로 스크립트 실행을 막고 있으므로
쉘스크립트 파일의 실행을 허용하도록 PowerShell 실행정책 변경 필요
PS C:\Users\SKTelecom> Set-ExecutionPolicy RemoteSigned -Scope CurrentUser
PS C:\Users\SKTelecom>
PS C:\Users\SKTelecom> Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
#>